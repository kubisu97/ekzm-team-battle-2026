// Firebase Web アプリの公開設定 (秘密鍵ではありません)
export const firebaseConfig = {
  apiKey: 'AIzaSyDBDUXL_28_ONiCitFOcYKJ5DocDVLdaFA',
  authDomain: 'ekzam-team-battle-2026.firebaseapp.com',
  databaseURL: 'https://ekzam-team-battle-2026-default-rtdb.firebaseio.com',
  projectId: 'ekzam-team-battle-2026',
  storageBucket: 'ekzam-team-battle-2026.firebasestorage.app',
  messagingSenderId: '1076057894320',
  appId: '1:1076057894320:web:6b40a2f6884b1b5dc0ba75',
  measurementId: 'G-G5FBCW665X'
};
// Firebase Authentication > ユーザー > 管理者の UID をコピーして設定
export const ADMIN_UID = 'uBDBPDOsN9OphJoSg1KHAIXonSA2';
