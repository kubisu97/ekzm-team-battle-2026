# EKZM TEAM BATTLE 2026

Firebase Realtime Databaseを使った5チーム対抗ゲーム。

## 公開手順
1. Firebase Console > Realtime Database > ルール に `database.rules.json` を貼り付けて「公開」。
2. GitHubリポジトリ直下へ `index.html`, `app.js`, `firebase-config.js` をアップロード。
3. Settings > Pages > Deploy from a branch > main / (root) で保存。
4. Firebase Authentication > Settings > Authorized domains に `kubisu97.github.io` を追加（必要なら）。
5. 複数スマホで管理者と参加者を分けて試験。

※パスワードはリポジトリへ置かない。
