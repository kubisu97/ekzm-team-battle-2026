EKZM TEAM BATTLE 2026 - Firebase / GitHub Pages 用
=================================================

構成:
 index.html                 参加者・管理者画面
 app.js                     ゲーム本体（Firebase CDN SDK 11.10.0）
 firebase-config.js         既存Firebaseプロジェクトの公開設定 / 管理者UID
 database.rules.json        Realtime Database用セキュリティルール

【必須設定 1】管理者アカウント作成
  Firebase Console > Authentication > ユーザー > ユーザーを追加
  メールとパスワード方式で管理者用アカウントを追加。
  「ユーザー」一覧から管理者の「UID」をコピー。
  ※ UIDや設定値は個人のパスワードではありません。パスワード自体は共有しないでください。

【必須設定 2】管理者UIDを2ファイルに設定
  firebase-config.js の uBDBPDOsN9OphJoSg1KHAIXonSA2 を管理者UIDに置換。
  database.rules.json の uBDBPDOsN9OphJoSg1KHAIXonSA2 も同じUIDに置換。
  UIDを置換せず公開すると管理者が動作しません。

【必須設定 3】Realtime Databaseルールを反映
  Firebase Console > Realtime Database > ルール
  database.rules.jsonの内容を貼り付けて公開。
  ※ 認証は「匿名」と「メール/パスワード」の両方を有効化。
  ※ .read:true / .write:true の全公開ルールに変更しないでください。

【必須設定 4】GitHub Pages
  GitHubでPublicの新規リポジトリ ekzm-team-battle-2026 を作成。
  このフォルダー内の index.html, app.js, firebase-config.js を
  リポジトリ直下にアップロード。（database.rules.jsonは公開不要）
  Settings > Pages > Build and deployment > Deploy from a branch
  main / (root) を選択し保存。
  数分後、https://<GitHubユーザー名>.github.io/ekzm-team-battle-2026/
  を開けるようになる。これをQRとして使う。

【当日の流れ】
  管理者: URLを開く > 管理者ログイン > メール/パスワード入力
  参加者: 同じURLを開く > 名前・チームを選択 > 登録
  管理者: 各チームの未出場代表者を選択 > 代表者を確定 > 一斉スタート
  プレイヤー: 10秒 / 早押し / 居合斬り / 連打をプレイ
  観客: 対戦中の代表者と結果をスマホで閲覧
  管理者: 5人終了を確認して「結果を確定・発表」
  管理者: 「次のゲーム」 > 代表者を交代して4ラウンド

【注意】
 - 全員は各自のモバイル回線で参加できます。HTTPS公開が必要です。
 - ゲーム初期化は管理者ログインで行われます。管理者が先にログインしてください。
 - ゲーム結果は各スマホで計測され送信されます。厳密な競技・不正対策用途ではありません。
 - 機種や通信の差により反射神経測定に誤差が生じます。
 - Firebaseのルールは必ず設定・確認してください。
 - ファイルを直接ダブルクリックするとブラウザのモジュール制限により動作しない場合があります。
   GitHub PagesなどのHTTPS Webサーバーに公開して動作確認してください。
 - 初期のクイズ問題はサンプル12問。app.jsのQUESTIONSを編集できます。
 - 管理者は同じ端末・ブラウザで参加者と兼用しません（別のブラウザプロファイルを使ってください）。

【今回の作業状況】
管理者UIDは設定済み。GitHubへの書き込みは連携アプリ権限403で保留。
FirebaseのルールはConsoleのルールタブに手動反映が必要です。
